/**
 *
 * @author Anuradha Shikhare
 *
 * starts the progress bar demo
 *
 */
$(document).ready(function () {
	products =[
    {
        "id": "1",
        "title": "Mango",
        "description": "Mangoes are generally sweet, although the taste and texture of the flesh varies across cultivars; some have a soft, pulpy texture similar to an overripe plum, while others are firmer, like a cantaloupe or avocado, and some may have a fibrous texture. The skin of unripe, pickled, or cooked mango can be consumed, but has the potential to cause contact dermatitis of the lips, gingiva, or tongue in susceptible people.",
		"image": "Mango.jpg"
    },
    {
	"id": "2",
	"title": "Apple",
	"description": "Apples are often eaten raw. The whole fruit including the skin is suitable for human consumption except for the seeds, which may affect some consumers.[citation needed] The core is often not eaten and is discarded. Varieties bred for raw consumption are termed dessert or table apples." ,
	"image": "Apple.jpg"
    },
    {
	"id": "3",
	"title": "Grapes",
	"description": "Grapes can be eaten raw or they can be used for making wine, jam, juice, jelly, grape seed extract, raisins, vinegar, and grape seed oil. Grapes are a non-climacteric type of fruit, generally occurring in clusters. Grapes are a type of fruit that grow in clusters of 15 to 300, and can be crimson, black, dark blue, yellow, green, orange, and pink. White grapes are actually green in color, and are evolutionarily derived from the purple grape." ,
	"image": "Grapes.jpg"
    },
    {
	"id": "4",
	"title": "Strawberry",
	"description": "The strawberry is widely appreciated for its characteristic aroma, bright red color, juicy texture, and sweetness. It is consumed in large quantities, either fresh or in such prepared foods as preserves, fruit juice, pies, ice creams, milkshakes, and chocolates. Artificial strawberry flavorings and aromas are also widely used in many products like lip gloss, candy, hand sanitizers, perfume, and many others.",
	"image": "Strawberry.jpg"
    },
    {
	"id": "5",
	"title": "Watermelon",
	"description": "It is grown for its edible fruit, also known as a watermelon, which is a special kind of berry botanically called a pepo. The fruit has a smooth hard rind, usually green with dark green stripes or yellow spots, and a juicy, sweet interior flesh, usually deep red to pink, but sometimes orange, yellow, or white, with many seeds.",
	"image": "Watermelon.jpg"
    },
    {
	"id": "6",
	"title": "Kiwi",
	"description": "The kiwifruit or Chinese gooseberry (often shortened to kiwi) is the edible berry of a woody vine in the genus Actinidia. It has a fibrous, dull greenish-brown skin and bright green or golden flesh with rows of tiny, black, edible seeds. The fruit has a soft texture and a sweet but unique flavor.",
	"image": "Kiwi.jpg"
    },
    {
	"id": "7",
	"title": "Pomegranate",
	"description": "The edible fruit is a berry, intermediate in size between a lemon and a grapefruit, 5–12 cm (2.0–4.7 in) in diameter with a rounded shape and thick, reddish skin. The number of seeds in a pomegranate can vary from 200 to about 1400.[9] Each seed has a surrounding water-laden pulp — the edible sarcotesta that forms from the seed coat — ranging in color from white to deep red or purple.",
	"image": "Pomegranate.jpg"
    },
    {
	"id": "8",
	"title": "Pineapple",
	"description": "Pineapples can be consumed fresh, cooked, juiced, or preserved. They are found in a wide array of cuisines. In addition to consumption, the pineapple leaves are used to produce the textile fiber piña in the Philippines, commonly used as the material for the men's Barong Tagalog and women's Baro't saya formal wear in the country. The fiber is also used as a component for wallpaper and other furnishings.",
	"image": "Pineapple.jpg"
    },
    {
	"id": "9",
	"title": "Cherry",
	"description": "The cherry fruits of commerce usually are obtained from a limited number of species such as cultivars of the sweet cherry, Prunus avium. The name 'cherry' also refers to the cherry tree, and is sometimes applied to almonds and visually similar flowering trees in the genus Prunus, as in 'ornamental cherry', 'cherry blossom', etc. ",
	"image": "Cherry.jpg"
    },
    {
	"id": "10",
	"title": "Pear",
	"description": "Pears and apples cannot always be distinguished by the form of the fruit; some pears look very much like some apples, e.g. the nashi pear. One major difference is that the flesh of pear fruit contains stone cells (also called 'grit').",
	"image": "Pear.jpg"
    },
    {
	"id": "11",
	"title": "Passionfruit",
	"description": "The passion fruit is a pepo, a type of berry, round to oval, either yellow or dark purple at maturity, with a soft to firm, juicy interior filled with numerous seeds. The fruit is both eaten and juiced; passion fruit juice is often added to other fruit juices to enhance aroma.[",
	"image": "Passionfruit.jpg"
    },
    {
	"id": "12",
	"title": "Mandarin",
	"description": "Mandarins are smaller and less spherical than common oranges (which are a mandarin hybrid). The taste is considered less sour, as well as sweeter and stronger. A ripe mandarin is firm to slightly soft, heavy for its size, and pebbly-skinned. The peel is very thin, with very little bitter white mesocarp, so they are usually easier to peel and to split into segments.",
	"image": "Mandarin.jpg"
    },
    {
	"id": "13",
	"title": "Jackfruit",
	"description": "Jackfruit have a distinctive sweet and fruity aroma. a fully ripe and unopened jackfruit is known to 'emit a strong aroma,' with the inside of the fruit described as smelling of pineapple and banana.",
	"image": "Jackfruit.jpg"
    },
    {
	"id": "14",
	"title": "Blueberry",
	"description": " They have a sweet taste when mature, with variable acidity. Blueberry bushes typically bear fruit in the middle of the growing season: fruiting times are affected by local conditions such as altitude and latitude, so the peak of the crop can vary from May to August (in the northern hemisphere) depending upon these conditions.",
	"image": "Blueberry.jpg"
    },
    {
	"id": "15",
	"title": "Banana",
	"description": "The fruit is variable in size, color, and firmness, but is usually elongated and curved, with soft flesh rich in starch covered with a rind which may be green, yellow, red, purple, or brown when ripe. The fruits grow in clusters hanging from the top of the plant.",
	"image": "Banana.jpg"
    }
];
	var productObj = new Products(products);
	productObj.displayProducts();
	$("#show-more").click(function(){
		productObj.loadNextProducts();
	});
	$(document).on('click','a',function() {
		productObj.showDetail(this.id);
	});
});

