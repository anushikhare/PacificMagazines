/**
 *
 * @author Anuradha Shikhare
 *
 * Handles the display of product catalogue and interactions
 *
 */

function Products(products) {
   this._products = products;
}
var lastLoadedIndex=9;

Products.prototype = {
    displayProducts : function() {
		var htmlContent = "<ul>";
		$.each(this._products.slice(0,10), function(key, product) {
		    htmlContent += "<li><a id='"+ key +"' data-toggle='modal' data-target='#myModal' href='#'>"+ product.title + "</a></li>";
	    });
		htmlContent += "</ul>";
		$("#product-list").append(htmlContent);
	},
	
	loadNextProducts : function() {
		var htmlContent = "";
		$.each(this._products.slice(lastLoadedIndex+1,lastLoadedIndex+6), function(key, product) {
			lastLoadedIndex++;
			htmlContent += "<li><a id='"+ lastLoadedIndex +"' data-toggle='modal' data-target='#myModal' href='#'>"+ product.title + "</a></li>";
			
	    });
		$("#product-list > ul").append(htmlContent);
	},
	showDetail : function(id) {
		var product;
		$.each(this._products, function(key, value){
			if(key==id) 
				product = value;
		});
		var htmlContent = "<h3>" + product.title + "</h3>";
		htmlContent += "<p>" + product.description + "</p>";
		htmlContent += "<img src='./images/" + product.image + "'/>";
		$('#product-description').html(htmlContent);
	}
}